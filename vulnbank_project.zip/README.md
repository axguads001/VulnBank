# VulnBank - Modern Vulnerable Banking App

## Features
- SQLi on login
- Basic session management
- Simple Flask app with Docker support

## Setup
```bash
docker-compose up --build
```

Visit: http://localhost:5000